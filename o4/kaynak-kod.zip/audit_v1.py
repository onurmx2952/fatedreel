"""Frozen v1 audit. Coefficients and seeds are unchanged."""
from pathlib import Path
from collections import deque
import json, hashlib
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from research.v1 import model_v1 as v1

KEYS=v1.METRICS

def frozen_map(x,A=.6,D=.65,S=.2,F=.3,B=.8,r=1.,shock=1.,protest=1.,bounded=True):
    C,L,V,W,T,I=x
    P=np.clip(.015+protest*(1-W)*(1-T)*.22,0,1)
    dw=shock*(-.012*.14-.006*.10-.004*.06)
    dv=shock*(.006*.035+.004*.08)
    y=np.array([C+.035*(A-.5)+.025*V+.018*P*S-.035*I*D,
       L+.035*I*D-.030*C*A-.020*P*S,
       .90*V+.045*P*(1-L)+.035*F*(1-T)+dv-.025*T*I,
       W+.018*(.65-W)+.012*T+.008*B-.025*V-.012*C*(1-I)+dw,
       T+.020*(W-.5)+.012*L*I-.025*V-.010*P,
       I+r*(.6-C)*.035-.020*C*A])
    return np.clip(y,0,1) if bounded else y

def jacobian(fn,x,h=1e-6):
    # one-sided at boundaries: constrained-domain derivative
    j=np.zeros((len(x),len(x)))
    for k in range(len(x)):
        a=np.array(x,dtype=float);b=a.copy();a[k]=max(0,x[k]-h);b[k]=min(1,x[k]+h)
        j[:,k]=(fn(b)-fn(a))/(b[k]-a[k])
    return j

def fixed_points():
    rows=[]
    for A in [.35,.6,.85]:
        fn=lambda x:frozen_map(x,A=A)
        found=[]
        for start in [list(v) for v in v1.SCENARIOS.values()]+[[0,1,0,1,1,1],[1,0,.25,0,0,0],[.5]*6]:
            # Iterate for attractors; least squares also searches other roots.
            x=np.array(start,dtype=float)
            for _ in range(4000):x=fn(x)
            candidates=[x,least_squares(lambda x:fn(x)-x,np.clip(start,1e-8,1-1e-8),bounds=(0,1),gtol=1e-12,ftol=1e-12,xtol=1e-12).x]
            for x in candidates:
                residual=float(np.max(np.abs(fn(x)-x)))
                if residual>1e-7 or any(np.linalg.norm(x-y)<1e-4 for y in found):continue
                found.append(x)
                eig=np.linalg.eigvals(jacobian(fn,x));rho=float(np.max(np.abs(eig)))
                rows.append({'A':A,**dict(zip(KEYS,map(float,x))),'residual':residual,'spectral_radius':rho,'eigenvalues':[{'real':float(z.real),'imag':float(z.imag)} for z in eig],'local_label':'çekici (donmuş kapanış)' if rho<1-1e-5 else 'kararsız/sınır durum'})
    return rows

def audit():
    folder=Path('audit_results');folder.mkdir(exist_ok=True)
    rawrows=[];history=[];events=[];outcomes=[];endogenous=[]
    original=v1.clip;buffer=deque(maxlen=6)
    def monitored(x):buffer.append(float(x));return original(x)
    v1.clip=monitored
    try:
        for i in range(100):
            m=v1.RevolutionModel(2026+i)
            for _ in range(240):
                previous=m.state.copy();m.step()
                rawrows.append({'run':i,'month':m.month,**{'raw_'+k:v for k,v in zip(KEYS,buffer)},**{'delta_'+k:m.state[k]-previous[k] for k in KEYS}})
                co=[a for a in m.people if a.role in ('Lider','Fraksiyon')];w=[a.resources*(1+len(a.allies))+.01 for a in co]
                endogenous.append({'run':i,'month':m.month,'A':.5*(sum(a.hardness*b for a,b in zip(co,w))/sum(w)+m.leader.hardness),'D':float(np.mean([a.preference for a in m.people if a.role in ('Vatandaş','Muhalefet')])),'S':float(np.mean([a.trust*a.resources for a in m.people if a.role in ('Ordu','Polis')])),'F':float(2*np.std([a.preference for a in co])),'B':float(np.mean([a.resources for a in m.people if a.role=='İşletme']))})
            h=pd.DataFrame(m.history);h['run']=i;h['seed']=2026+i;history.append(h)
            e=pd.DataFrame(m.events);e['run']=i;events.append(e)
            outcomes.append({'run':i,'seed':2026+i,'regime':v1.classify(h),**h.iloc[-1][KEYS].to_dict()})
            if i%20==19:print('v1 audit',i+1,flush=True)
    finally:v1.clip=original
    h=pd.concat(history,ignore_index=True);e=pd.concat(events,ignore_index=True);o=pd.DataFrame(outcomes);raw=pd.DataFrame(rawrows);agg=pd.DataFrame(endogenous)
    h.to_csv(folder/'monthly.csv',index=False);raw.to_csv(folder/'raw_updates.csv',index=False);agg.to_csv(folder/'micro_aggregates.csv',index=False)
    late=h[h.month>=80];stats=[]
    for k in KEYS:
        vals=raw['raw_'+k]
        stats.append({'metric':k,'exact_boundary_share_all':float(h[k].isin([0,1]).mean()),'exact_boundary_share_after_80':float(late[k].isin([0,1]).mean()),'raw_below_zero_share':float((vals<0).mean()),'raw_above_one_share':float((vals>1).mean()),'late_annual_sd_mean':float(h[h.month>=180].groupby('run')[k].std().mean())})
    # Joint saturation, measured per run, not inferred from medians.
    sats=[]
    for run,g in h.groupby('run'):
        mask=(g.liberties>=.99)&(g.trust>=.99)&(g.independence>=.99)&(g.concentration<=.01)
        hits=g.loc[mask,'month']
        sats.append({'run':int(run),'first_joint_near_boundary_month':int(hits.iloc[0]) if len(hits) else None,'share_after80':float(mask[g.month>=80].mean())})
    # Native saved data reproduction audit
    saved=pd.read_csv('results/monthly.csv')
    pd.testing.assert_frame_equal(h[saved.columns],saved,check_exact=False,atol=1e-13)
    # Event study: descriptive same-path changes, not causal counterfactuals.
    impacts=[]
    for row in e[e.event.str.contains('Ekonomik kriz|Kıtlık|Dış müdahale')].itertuples():
        if row.month+12>240:continue
        g=h[h.run==row.run].set_index('month');pre=g.loc[row.month-1]
        impacts.append({'run':row.run,'month':row.month,'event':row.event,'prosperity_immediate':float(g.loc[row.month,'prosperity']-pre.prosperity),'prosperity_after12':float(g.loc[row.month+12,'prosperity']-pre.prosperity),'trust_after12':float(g.loc[row.month+12,'trust']-pre.trust)})
    # Paired shocks on/off: all RNG streams remain seeded but branch RNG draws can desynchronize.
    _,_,off=v1.experiment(v1.Parameters(shock_scale=0),100,2026)
    off.to_csv(folder/'no_shock_outcomes.csv',index=False)
    summary={'source_sha256':hashlib.sha256(Path('research/v1/model_v1.py').read_bytes()).hexdigest(),'seeds':list(range(2026,2126)),'runs':100,'horizon':240,'distribution':o.regime.value_counts().to_dict(),'no_shock_distribution':off.regime.value_counts().to_dict(),'boundaries':stats,'joint_saturation':sats,'fixed_points_frozen':fixed_points(),'state_correlations_late':late[KEYS].corr().to_dict(),'increment_correlations':raw[['delta_'+k for k in KEYS]].corr().to_dict(),'aggregate_means_early':agg[agg.month<=12].mean(numeric_only=True).to_dict(),'aggregate_means_late':agg[agg.month>=180].mean(numeric_only=True).to_dict(),'event_study':pd.DataFrame(impacts).groupby('event').mean(numeric_only=True).to_dict(),'warning':'Donmuş makro kapanışın sabit noktaları tam stokastik etmen sisteminin kararlılık kanıtı değildir.'}
    (folder/'audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(impacts).to_csv(folder/'event_study.csv',index=False)
    o.to_csv(folder/'outcomes.csv',index=False)
    print(json.dumps({k:summary[k] for k in ['distribution','no_shock_distribution','boundaries']},ensure_ascii=False),flush=True)
if __name__=='__main__':audit()
