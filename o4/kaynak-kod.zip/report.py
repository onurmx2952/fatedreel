import json
from pathlib import Path
import pandas as pd
from model import METRICS, wilson
p=Path('results');h=pd.read_csv(p/'monthly.csv');o=pd.read_csv(p/'outcomes.csv')
lines=['# Hesaplanan deney ve doğrulama raporu','', 'Bu rapor sentetik model çıktılarıdır; Fransa tahmini değildir.','',f'Ana deney: {len(o)} bağımsız tohum, 240 aylık geçiş; {len(h)} kayıt.','', '## Ana sonuçlar','']
for regime,k in o.regime.value_counts().items():
    lo,hi=wilson(k,len(o));lines.append(f'- {regime}: {k}/{len(o)}, Wilson %95 aralığı %{lo*100:.1f}–%{hi*100:.1f}.')
lines+=['','## Sayısal doğrulama','',f'Sonlu ve [0,1] aralığındaki endeksler: {bool(h[METRICS].ge(0).all().all() and h[METRICS].le(1).all().all())}.','', 'Sınırda (0 veya 1) aylık gözlem payları:','']
for key in METRICS:lines.append(f'- {key}: %{100*h[key].isin([0,1]).mean():.1f}')
lines+=['','Yüksek sınır payları modelin clip ve geri besleme yapısının etkisidir; ampirik kesinlik göstermez. İç savaşın bu örneklemde görülmemesi yapısal olarak imkânsız olduğunu kanıtlamaz; bu sınıfın erişilebilirliği ve şiddet dinamiklerinin kalibrasyonu ayrıca araştırılmalıdır.','']
if (p/'scenario_comparison.csv').exists():
    df=pd.read_csv(p/'scenario_comparison.csv');lines+=['## Başlangıç koşulları','',df.groupby(['scenario','regime']).size().to_string(),'']
if (p/'sensitivity.csv').exists():
    df=pd.read_csv(p/'sensitivity.csv');lines+=['## Tek etkenli duyarlılık','',df.to_string(index=False),'','Pay farkları eşleştirilmiş tohumlarla hesaplanmıştır. paired_mc_se farkın Monte Carlo standart hatasıdır; model belirsizliği değildir.']
Path('RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines[:16]))
