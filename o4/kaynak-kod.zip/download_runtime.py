from pathlib import Path
import requests, concurrent.futures, hashlib
base='https://cdn.jsdelivr.net/pyodide/v314.0.6/full/'
p=Path('web/runtime');p.mkdir(exist_ok=True)
r=requests.get(base+'pyodide-lock.json',timeout=45);r.raise_for_status();d=r.json();(p/'pyodide-lock.json').write_bytes(r.content)
names=set()
def add(name):
    if name in names:return
    names.add(name)
    for dep in d['packages'][name]['depends']:add(dep)
for name in ['micropip','numpy','pandas','scipy','networkx','tqdm']:add(name)
files=[('pyodide.mjs',None),('pyodide.js',None),('pyodide.asm.mjs',None),('pyodide.asm.wasm',None),('python_stdlib.zip',None)]+[(d['packages'][n]['file_name'],d['packages'][n]['sha256']) for n in sorted(names)]
def fetch(item):
    name,sha=item; path=p/name
    if path.exists() and (not sha or hashlib.sha256(path.read_bytes()).hexdigest()==sha):return name,path.stat().st_size
    rr=requests.get(base+name,timeout=120);rr.raise_for_status()
    if sha:assert hashlib.sha256(rr.content).hexdigest()==sha,name
    path.write_bytes(rr.content);return name,len(rr.content)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    for name,size in pool.map(fetch,files):print(name,size,flush=True)

