import itertools
import numpy as np
import pandas as pd
import pytest
from dataclasses import replace
import model_v2 as v2
from model import METRICS,SCENARIOS,classify

MICRO=np.array([.5,.5,.4,.5,.5,.5,.5,.5])

def test_corner_boundaries_are_not_absorbing():
    for x in itertools.product([0.,1.],repeat=6):
        y=v2.flow_map(x,MICRO,np.zeros(3),0,v2.Parameters())
        assert np.all(y>0) and np.all(y<1)

def test_finite_domain_under_random_pressures():
    rng=np.random.default_rng(71)
    for _ in range(500):
        x=rng.uniform(size=6);pressures=rng.normal(0,4,3);micro=rng.uniform(size=8)
        y=v2.flow_map(x,micro,pressures,rng.uniform(-1,1),v2.Parameters(),rng.normal(0,.18,6))
        assert np.isfinite(y).all() and np.all((y>=0)&(y<=1))

def test_reproducibility_and_seed_variability():
    a,ae=v2.RevolutionModel(42).run(36);b,be=v2.RevolutionModel(42).run(36);c,_=v2.RevolutionModel(43).run(36)
    pd.testing.assert_frame_equal(a,b);pd.testing.assert_frame_equal(ae,be);assert not a.equals(c)

@pytest.mark.parametrize('scenario',SCENARIOS)
def test_full_horizon_and_micro_invariants(scenario):
    m=v2.RevolutionModel(2026,v2.Parameters(scenario=scenario));h,e=m.run()
    assert len(h)==241 and np.isfinite(h[METRICS]).all().all()
    assert h[METRICS].gt(0).all().all() and h[METRICS].lt(1).all().all()
    lookup={a.unique_id:a for a in m.people}
    for a in m.people:
        assert all(0<x<1 for x in [a.resources,a.trust,a.preference,a.hardness])
        for peer in a.allies:assert a.unique_id in lookup[peer].allies

def test_split_rng_streams_survive_shock_intervention():
    a=v2.RevolutionModel(2026);b=v2.RevolutionModel(2026,v2.Parameters(shock_scale=0))
    a.run(60);b.run(60)
    assert a.events_rng.getstate()==b.events_rng.getstate()
    assert a.macro_rng.getstate()==b.macro_rng.getstate()
    assert a.leader_rng.getstate()==b.leader_rng.getstate()

def test_no_macro_clipping(monkeypatch):
    import model
    def forbidden(x):raise AssertionError('V2 eski clip fonksiyonuna başvurmamalı')
    monkeypatch.setattr(model,'clip',forbidden)
    v2.RevolutionModel(4).run(12)

def test_pressure_has_memory():
    m=v2.RevolutionModel(8,v2.Parameters(shock_scale=0));m.pressure=np.array([1.,0.,0.])
    m.update_pressures()
    assert .6<m.pressure[0]<1.3

def test_experiment_same_predeclared_classifier():
    h,e,o=v2.experiment(runs=3,months=24,base_seed=100)
    assert len(h)==75 and o.seed.tolist()==[100,101,102]
    for row in o.itertuples():assert classify(h[h.run==row.run])==row.regime

def test_parameters_reject_nan():
    with pytest.raises(ValueError):v2.Parameters(self_feedback=float('nan'))
