from dataclasses import replace
import numpy as np
import pandas as pd
import pytest
from model import *

def test_reproducibility_and_seed_variation():
    a,ae=RevolutionModel(42).run(24);b,be=RevolutionModel(42).run(24);c,_=RevolutionModel(43).run(24)
    pd.testing.assert_frame_equal(a,b);pd.testing.assert_frame_equal(ae,be)
    assert not a.equals(c)

@pytest.mark.parametrize('scenario',SCENARIOS)
def test_horizon_bounds_and_alliances(scenario):
    m=RevolutionModel(20,Parameters(scenario=scenario));h,e=m.run()
    assert len(h)==241 and h.month.tolist()==list(range(241))
    assert np.isfinite(h[METRICS]).all().all()
    assert h[METRICS].ge(0).all().all() and h[METRICS].le(1).all().all()
    lookup={a.unique_id:a for a in m.people}
    for a in m.people:
        for peer in a.allies:assert a.unique_id in lookup[peer].allies
    assert set(a.role for a in m.people)==set(ROLES)

def test_shocks_disabled():
    _,e=RevolutionModel(2,Parameters(shock_scale=0)).run()
    assert not e.event.str.contains('Ekonomik kriz|Kıtlık|Dış müdahale').any()

@pytest.mark.parametrize('values,result',[
    ([.8,.2,.1,.4,.3,.2],'Otoriter'),([.2,.8,.1,.8,.7,.8],'Demokrasi'),
    ([.8,.2,.7,.3,.2,.1],'İç savaş'),([.5,.5,.2,.5,.5,.2],'Kırılgan yönetim'),
    ([.5,.5,.2,.5,.5,.5],'Hibrit'),([.7,.35,.2,.5,.5,.35],'Otoriter')])
def test_classifier(values,result):
    assert classify(pd.DataFrame([values],columns=METRICS))==result

def test_experiment_seeds_and_metadata():
    h,e,o=experiment(runs=3,months=12,base_seed=99)
    assert len(h)==39 and o.seed.tolist()==[99,100,101]
    assert len(o)==3

def test_invalid_parameters():
    with pytest.raises(ValueError):Parameters(shock_scale=-1)

def test_wilson():
    lo,hi=wilson(0,100);assert lo==0 and .03<hi<.04
