from streamlit.testing.v1 import AppTest

def test_default_app_and_navigation():
    app=AppTest.from_file('../app.py',default_timeout=120).run()
    assert not app.exception
    assert app.title[0].value=='Devrimden Sonra 20 Yıl'
    assert len(app.session_state['result'][2])==100
    next(s for s in app.slider if s.label=='Görünür ay').set_value(120).run()
    assert not app.exception
    next(x for x in app.sidebar.selectbox if x.label=='Başlangıç senaryosu').select('Uzlaşma')
    app.sidebar.button[0].click().run(timeout=120)
    assert not app.exception
    assert app.session_state['config']['parameters']['scenario']=='Uzlaşma'



