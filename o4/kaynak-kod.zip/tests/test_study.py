from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import pytest
from model import METRICS,classify

@pytest.fixture(scope='module')
def study():
    path=Path('v2_results/analysis.json')
    if not path.exists():pytest.skip('Tam araştırma serisi henüz üretilmedi')
    return json.loads(path.read_text(encoding='utf-8'))

def test_preregistered_source_and_spec_unchanged(study):
    assert hashlib.sha256(Path('model_v2.py').read_bytes()).hexdigest()==study['source_sha256']
    assert hashlib.sha256(Path('MODEL_V2.md').read_bytes()).hexdigest()==study['preregistration']['spec_sha256']
    assert study['preregistration']['target_regime_shares'] is None

def test_all_predeclared_experiments_valid(study):
    assert len(study['summaries'])==15
    for summary in study['summaries']:
        folder=Path('v2_results')/summary['name'];h=pd.read_csv(folder/'monthly.csv');o=pd.read_csv(folder/'outcomes.csv')
        assert len(h)==24100 and len(o)==100
        assert o.seed.tolist()==list(range(2026,2126))
        assert h[METRICS].gt(0).all().all() and h[METRICS].lt(1).all().all()
        for run,g in h.groupby('run'):
            assert g.month.tolist()==list(range(241))
            assert classify(g)==o.loc[o.run==run,'regime'].iloc[0]
        assert sum(summary['distribution'].values())==100

def test_frozen_roots_residuals(study):
    assert len(study['fixed_points_frozen'])>0
    assert max(r['residual'] for r in study['fixed_points_frozen'])<1e-7
    # Report both attracting and unstable examples, without claiming exhaustive roots.
    assert any(r['spectral_radius']<1 for r in study['fixed_points_frozen'])
    assert any(r['spectral_radius']>1 for r in study['fixed_points_frozen'])
