import json
from pathlib import Path
import pandas as pd
from model import classify, METRICS

def test_saved_experiment_contract():
    path=Path('results/experiment.json')
    if not path.exists(): return
    data=json.loads(path.read_text(encoding='utf-8'))
    h=pd.DataFrame(data['monthly']);o=pd.DataFrame(data['outcomes'])
    assert data['metadata']['runs']==100
    assert len(h)==24100 and len(o)==100
    assert h.groupby('seed').size().eq(241).all()
    for row in o.itertuples():
        assert classify(h[h.seed==row.seed])==row.regime
