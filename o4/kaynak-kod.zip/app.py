import json
import time
import platform
import mesa
from dataclasses import asdict
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st
from model import Parameters, SCENARIOS, METRICS, LABELS, experiment, sensitivity, wilson
import model_v2

st.set_page_config(page_title='Devrimden Sonra 20 Yıl',page_icon='◈',layout='wide')
st.markdown('''<style>.stApp{background:#0c1420;color:#e5eaf2} h1{font-family:Georgia,serif!important;font-size:3.2rem!important} [data-testid="stMetric"]{background:#172334;padding:18px;border-radius:8px;border-top:2px solid #e6ae67} .stCaption{color:#9cabbf} section[data-testid="stSidebar"]{background:#111d2c}</style>''',unsafe_allow_html=True)
st.caption('FATEDREEL / ARAŞTIRMA LABORATUVARI / 01')
st.title('Devrimden Sonra 20 Yıl')
st.markdown('Bir iktidar değişimi, yüz farklı yol. **2026–2045 · 240 ay · etmen tabanlı deney**')
st.warning('Varsayımsal bir Fransa senaryosudur. Gerçek Fransa’nın geleceğini tahmin etmez. Sonuçlar kalibre edilmemiş model varsayımlarına koşulludur.')
with st.sidebar:
    st.header('Deney tasarımı')
    with st.form('parameters'):
        version=st.selectbox('Model sürümü',['2.0','1.0'],format_func=lambda x:'V2 · araştırma adayı' if x=='2.0' else 'V1 · denetlenmiş arşiv')
        scenario=st.selectbox('Başlangıç senaryosu',list(SCENARIOS))
        resilience=st.slider('Kurumsal dayanıklılık',0.,3.,1.,.1)
        shocks=st.slider('Kriz ve müdahale olasılığı çarpanı',0.,3.,1.,.1)
        protests=st.slider('Protesto olasılığı çarpanı',0.,3.,1.,.1)
        bias=st.slider('Liderlerin başlangıç sertlik eğilimi',-.5,.5,0.,.05)
        feedback=st.slider('V2 · siyasi öz pekiştirme',0.,3.,1.,.1)
        resolution=st.slider('V2 · çatışma çözme kapasitesi',0.,3.,1.,.1)
        seed=st.number_input('Başlangıç tohumu',0,2147480000,2026)
        runs=st.selectbox('Bağımsız deney sayısı',[100,20,50],help='Bilimsel ana deney: 100. Diğer değerler hızlı keşif içindir.')
        submitted=st.form_submit_button('Deneyleri çalıştır',type='primary',width='stretch')
    st.caption('Her endeks 0–1 aralığındadır. Ay 0 başlangıçtır; 240 aylık geçiş hesaplanır.')
    st.page_link('https://pypi.org/project/Mesa/',label='Mesa sürüm kaynağı')

@st.cache_data(show_spinner=False,max_entries=8)
def cached_run(p,r,s,version='2.0'):
    engine=model_v2 if version=='2.0' else __import__('model')
    return engine.experiment(engine.Parameters(**p),r,s)

if submitted or 'result' not in st.session_state:
    params=model_v2.Parameters(scenario,resilience,shocks,protests,bias,feedback,resolution) if version=='2.0' else Parameters(scenario,resilience,shocks,protests,bias)
    with st.spinner(f'{runs} bağımsız deney hesaplanıyor…'):
        st.session_state.result=cached_run(asdict(params),runs,int(seed),version)
    st.session_state.config={'parameters':asdict(params),'runs':runs,'base_seed':int(seed),'months':240,'model_version':version,'python':platform.python_version(),'mesa':mesa.__version__,'classification':'Son 12 ay ortalamaları; MODEL.md'}
history,events,outcomes=st.session_state.result
config=st.session_state.config
st.warning('V1 sınır yığılması kusuruyla arşivlenmiştir. V2 bir araştırma adayıdır; siyasi endekslerde sınıra yakın kutuplaşma hâlâ görülür. İki sürüm de ampirik tahmin değildir.')
st.caption(f"Model V{config['model_version']} · GÖSTERİLEN DENEY: {config['parameters']['scenario']} / {config['runs']} tohum / başlangıç tohumu {config['base_seed']}. Yeni ayarları uygulamak için Deneyleri çalıştır düğmesine basın.")
auth=int((outcomes.regime=='Otoriter').sum());lo,hi=wilson(auth,len(outcomes))
a,b,c,d=st.columns(4)
a.metric('Deney',len(outcomes));b.metric('Otoriter sonuç',f'%{100*auth/len(outcomes):.0f}');c.metric('Monte Carlo %95 aralığı',f'%{lo*100:.1f}–{hi*100:.1f}');d.metric('Zaman ufku','20 yıl')
st.caption('Aralık yalnızca tohumlar arasındaki örnekleme değişkenliğini ölçer; modelin gerçek dünyaya ilişkin doğruluğunu ölçmez.')
compare,trajectory,annual,analysis,audit_tab,method,export=st.tabs(['20. yıl dağılımı','Tekil yollar','Yıllık anlatı','Duyarlılık ve kontrol','Matematik denetimi','Model ve varsayımlar','Dışa aktar'])
with trajectory:
    st.info('Bu grafik seçilen tek deneye aittir; 100 deneyin ortalaması değildir. Topluluk yüzdelikleri 20. yıl dağılımı sekmesindedir.')
    left,right=st.columns([3,1]);run=right.selectbox('Deney numarası',sorted(outcomes.run.unique()),format_func=lambda x:f'Deney {x+1}')
    selected=history[history.run==run]
    animate=right.button('▶ 20 yılı oynat')
    month=right.slider('Görünür ay',0,240,240)
    right.caption('Oynatma seçili deneyi baştan sona gösterir. Grafik değerleri aylık kayıtlardır.')
    right.write('Son rejim: **'+outcomes.loc[outcomes.run==run,'regime'].iloc[0]+'**')
    chart=left.empty()
    def draw(m):
        data=selected[selected.month<=m].melt(id_vars=['month'],value_vars=METRICS,var_name='Gösterge',value_name='Endeks')
        data['Gösterge']=data['Gösterge'].map(LABELS)
        fig=px.line(data,x='month',y='Endeks',color='Gösterge',range_y=[0,1],range_x=[0,240],template='plotly_dark',color_discrete_sequence=['#efa95d','#59d0b1','#ef7281','#77a6ef','#c8a3e8','#d0d57a'])
        fig.update_layout(height=490,xaxis_title='İktidar değişiminden sonraki ay',legend=dict(orientation='h',y=-.22),paper_bgcolor='#0c1420',plot_bgcolor='#0c1420')
        chart.plotly_chart(fig,width='stretch',key=f'path_{m}')
    if animate:
        for m in range(0,241,6):draw(m);time.sleep(.08)
    else:draw(month)
with compare:
    st.caption("Dağılımlar ve tablo ay 240 değerlerini gösterir. Rejim sınıfı son 12 ayın ortalamasıyla belirlenir.")
    l,r=st.columns(2)
    counts=outcomes.regime.value_counts().reindex(['Demokrasi','Otoriter','İç savaş','Kırılgan yönetim','Hibrit'],fill_value=0).rename_axis('Rejim').reset_index(name='Deney')
    l.plotly_chart(px.bar(counts,x='Rejim',y='Deney',color='Rejim',template='plotly_dark'),width='stretch')
    metric=r.selectbox('Dağılım göstergesi',METRICS,format_func=LABELS.get)
    r.plotly_chart(px.histogram(outcomes,x=metric,color='regime',nbins=20,template='plotly_dark',labels={metric:LABELS[metric],'regime':'Rejim'}),width='stretch')
    qs=history.groupby('month')[metric].quantile([.1,.5,.9]).unstack().reset_index();qs.columns=['month','%10','Medyan','%90']
    st.plotly_chart(px.line(qs,x='month',y=['%10','Medyan','%90'],template='plotly_dark',title=f'{LABELS[metric]} · deneyler arası yüzdelikler'),width='stretch')
    st.dataframe(outcomes.rename(columns=LABELS),width='stretch')
with annual:
    narrative_run=st.selectbox('Anlatılacak deney',sorted(outcomes.run.unique()),format_func=lambda x:f'Deney {x+1}')
    for y in range(20):
        start=y*12+1;end=(y+1)*12
        eh=events[(events.run==narrative_run)&events.month.between(start,end)]
        hh=history[(history.run==narrative_run)&history.month.between(start,end)]
        with st.expander(f'{2026+y} · {len(eh)} olay',expanded=y==0):
            if eh.empty:st.write('Bu yıl kayıtlı dışsal olay veya protesto gerçekleşmedi.')
            else:
                for text,count in eh.event.value_counts().items():st.write(f'• {text} ({count} ay/olay)')
            s=hh.iloc[-1];st.caption(f"Yıl sonu: refah {s.prosperity:.2f}, özgürlük {s.liberties:.2f}, şiddet {s.violence:.2f}.")
with analysis:
    st.subheader('Hangi varsayımlar sonucu değiştiriyor?')
    st.write('Tek etkenli tarama, aynı tohumları kullanır. Farklar seçili temel deneye göredir. Etkileşimler, yapısal belirsizlik ve gerçek dünya nedenselliği ölçülmez.')
    if st.button('Parametre duyarlılığını çalıştır'):
        bar=st.progress(0.)
        st.session_state.sensitivity=(config.copy(),(model_v2.sensitivity(model_v2.Parameters(**config['parameters']),config['runs'],config['base_seed'],bar.progress) if config['model_version']=='2.0' else sensitivity(Parameters(**config['parameters']),config['runs'],config['base_seed'],bar.progress)))
        bar.empty()
    if 'sensitivity' in st.session_state:
        sc,df=st.session_state.sensitivity
        st.caption('Duyarlılık temel yapılandırması: '+json.dumps(sc['parameters'],ensure_ascii=False))
        st.plotly_chart(px.bar(df,x='parameter',y='paired_difference',color='value',barmode='group',template='plotly_dark',labels={'paired_difference':'Otoriterlik payı farkı','parameter':'Parametre'}),width='stretch')
        st.dataframe(df,width='stretch')
    if st.button('Dört başlangıç senaryosunu karşılaştır'):
        rows=[];bar=st.progress(0.)
        for i,name in enumerate(SCENARIOS):
            p={**config['parameters'],'scenario':name};_,_,o=cached_run(p,config['runs'],config['base_seed'],config['model_version'])
            for regime,count in o.regime.value_counts().items():rows.append({'Senaryo':name,'Rejim':regime,'Pay':count/len(o)})
            bar.progress((i+1)/4)
        st.session_state.comparison=(config.copy(),pd.DataFrame(rows));bar.empty()
    if 'comparison' in st.session_state:
        cc,df=st.session_state.comparison
        st.caption(f"Karşılaştırma: her senaryoda {cc['runs']} deney; tohum {cc['base_seed']}; diğer parametreler: {cc['parameters']}")
        st.plotly_chart(px.bar(df,x='Senaryo',y='Pay',color='Rejim',template='plotly_dark'),width='stretch')
    st.subheader('Otoriter sonuçlarla ilişkili son durumlar')
    st.caption('Bu tablo tanımlayıcıdır. Sınıflama ölçütleriyle aynı değişkenleri kullandığından neden analizi değildir. Varsayım etkileri yukarıdaki kontrollü parametre taramasında incelenir.')
    st.dataframe(outcomes.groupby('regime')[METRICS].mean().rename(columns=LABELS))
with audit_tab:
    st.markdown(Path(__file__).with_name('AUDIT_V1.md').read_text(encoding='utf-8-sig'))
with method:
    doc='MODEL_V2.md' if config['model_version']=='2.0' else 'MODEL.md'
    st.markdown(Path(__file__).with_name(doc).read_text(encoding='utf-8-sig'))
    report=Path(__file__).with_name('STUDY_V2.md')
    if report.exists():st.markdown(report.read_text(encoding='utf-8-sig'))
with export:
    metadata={**config,'warning':'Varsayımsal ve kalibre edilmemiş model; Fransa tahmini değildir.'}
    st.download_button('Aylık kayıtlar · CSV',history.to_csv(index=False).encode('utf-8-sig'),'aylik_kayitlar.csv','text/csv')
    st.download_button('Deney sonuçları · CSV',outcomes.to_csv(index=False).encode('utf-8-sig'),'sonuclar.csv','text/csv')
    st.download_button('Olaylar · CSV',events.to_csv(index=False).encode('utf-8-sig'),'olaylar.csv','text/csv')
    payload={'metadata':metadata,'monthly':history.to_dict('records'),'events':events.to_dict('records'),'outcomes':outcomes.to_dict('records')}
    st.download_button('Tam deney ve parametreler · JSON',json.dumps(payload,ensure_ascii=False,indent=2),'deney.json','application/json')
    if 'sensitivity' in st.session_state:
        sc,df=st.session_state.sensitivity
        st.download_button('Duyarlılık · JSON',json.dumps({'config':sc,'results':df.to_dict('records')},ensure_ascii=False),'duyarlilik.json','application/json')

    if 'comparison' in st.session_state:
        cc,df=st.session_state.comparison
        st.download_button('Senaryo karşılaştırması · JSON',json.dumps({'config':cc,'results':df.to_dict('records')},ensure_ascii=False),'senaryolar.json','application/json')
        st.download_button('Senaryo karşılaştırması · CSV',df.to_csv(index=False).encode('utf-8-sig'),'senaryolar.csv','text/csv')
    if 'sensitivity' in st.session_state:
        _,df=st.session_state.sensitivity
        st.download_button('Duyarlılık · CSV',df.to_csv(index=False).encode('utf-8-sig'),'duyarlilik.csv','text/csv')

