import argparse,json,platform,time
from pathlib import Path
from dataclasses import asdict, replace
import mesa
import pandas as pd
from model import *
p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--runs',type=int,default=100);args=p.parse_args()
folder=Path('results');folder.mkdir(exist_ok=True)
params=Parameters();started=time.perf_counter()
h,e,o=experiment(params,args.runs)
h.to_csv(folder/'monthly.csv',index=False);e.to_csv(folder/'events.csv',index=False);o.to_csv(folder/'outcomes.csv',index=False)
meta={'parameters':asdict(params),'runs':args.runs,'base_seed':2026,'months':240,'python':platform.python_version(),'mesa':mesa.__version__,'model_version':'1.0','warning':'Varsayımsal; gerçek Fransa tahmini değildir.'}
(folder/'experiment.json').write_text(json.dumps({'metadata':meta,'monthly':h.to_dict('records'),'events':e.to_dict('records'),'outcomes':o.to_dict('records')},ensure_ascii=False),encoding='utf-8')
print('Ana deney:',o.regime.value_counts().to_dict(), 'saniye:',round(time.perf_counter()-started,1),flush=True)
if args.full:
    rows=[]
    for name in SCENARIOS:
        _,_,out=experiment(replace(params,scenario=name),args.runs)
        out['scenario']=name;rows.append(out)
        print('Senaryo:',name,out.regime.value_counts().to_dict(),flush=True)
    pd.concat(rows).to_csv(folder/'scenario_comparison.csv',index=False)
    sensitivity(params,args.runs,progress=lambda f:print('Duyarlılık',f,flush=True)).to_csv(folder/'sensitivity.csv',index=False)
print('Tamamlandı',round(time.perf_counter()-started,1),flush=True)
