from pathlib import Path
import json
import pandas as pd
p=Path('results')
meta=json.loads((p/'experiment.json').read_text(encoding='utf-8'))['metadata']
analysis={'metadata':meta,'method':'Tek etkenli eşleştirilmiş tohumlar; nedensel veya ampirik çıkarım değildir.','sensitivity':pd.read_csv(p/'sensitivity.csv').to_dict('records'),'scenario_outcomes':pd.read_csv(p/'scenario_comparison.csv').to_dict('records')}
(p/'analysis.json').write_text(json.dumps(analysis,ensure_ascii=False,indent=2),encoding='utf-8')
with Path('RESULTS.md').open('a',encoding='utf-8') as f:
    f.write('\n\nEn büyük tek etken etkisi lider_bias +0.25 varyantında görülmüştür: otoriter payı %10’dan %83’e çıkmıştır. Kurumsal dayanıklılık 0.5 olduğunda pay %18 olmuştur. Bu sonuçlar katsayıların ve başlangıç koşullarının ürünü olup gerçek Fransa hakkında tahmin değildir. Kontrolde ve uzlaşmada 100/100 demokrasi görülmesi, bu modelin olumlu başlangıçlarda güçlü çekim havzasına sahip olduğunu düşündürür; ampirik bir kesinlik iddiası değildir.\n')
