from pathlib import Path
import zipfile,json,hashlib
root=Path('.')
code=['WEB_VALIDATION_V2.md','package_research.py','README_RESEARCH.md','prepare_web_research.py','app.py','model.py','model_v2.py','audit_v1.py','run_v2_study.py','build_research_report.py','plot_research.py','run_experiments.py','report.py','finalize_results.py','download_runtime.py','MODEL.md','MODEL_V2.md','MODEL_V2_IMPLEMENTATION.md','AUDIT_V1.md','STUDY_V2.md','WEB_DEPLOYMENT.md','WEB_VALIDATION.md','requirements.txt','pytest.ini','Dockerfile','compose.yaml']
code += [str(p) for folder in ['tests','deploy','.streamlit'] for p in Path(folder).glob('*') if p.is_file()]
code += [str(p) for p in Path('research').rglob('*') if p.is_file() and p.suffix in ['.py','.md','.json'] and p.name!='experiment.json']
code += [str(Path('web')/name) for name in ['index.html','app.js','style.css','worker.js']]
with zipfile.ZipFile('web/kaynak-kod.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in code:z.write(name,name)
files=[Path('results/experiment.json'),Path('results/analysis.json'),Path('results/sensitivity.csv'),Path('results/scenario_comparison.csv')]
files+=list(Path('audit_results').glob('*'))
files+=list(Path('v2_results').glob('*.json'))
files+=list(Path('v2_results').glob('scenario_*/experiment.json'))
files+=list(Path('v2_results').glob('*/outcomes.csv'))+list(Path('v2_results').glob('*/summary.json'))
manifest={'warning':'Varsayımsal modeller; Fransa tahmini değildir.','files':[{'path':str(p).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files]}
with zipfile.ZipFile('web/research-data.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,str(p))
    z.writestr('data_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
for f in ['kaynak-kod.zip','research-data.zip']:
    size=Path('web',f).stat().st_size
    print(f,size)
    assert size<24*1024*1024
