from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from model import wilson,METRICS,LABELS
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
folder=Path('figures');folder.mkdir(exist_ok=True)
v1=pd.read_csv('results/outcomes.csv');v2=pd.read_csv('v2_results/scenario_0/outcomes.csv')
classes=['Demokrasi','Otoriter','İç savaş','Kırılgan\nyönetim','Hibrit'];keys=[c.replace('\n',' ') for c in classes];palette=['#1b9e77','#ca4c5a','#8c64b5','#cc9944','#4b78b0']
fig,axes=plt.subplots(1,2,figsize=(11,4.9),sharey=True,layout='constrained')
for ax,data,title in zip(axes,[v1,v2],['V1 · arşiv / matematik denetimi','V2 · araştırma adayı']):
    counts=np.array([(data.regime==k).sum() for k in keys]);intervals=np.array([wilson(int(k),100) for k in counts])*100
    ax.bar(np.arange(5),counts,color=palette,width=.65)
    ax.errorbar(np.arange(5),counts,yerr=np.vstack([counts-intervals[:,0],intervals[:,1]-counts]),fmt='none',color='#243143',capsize=4,lw=1)
    for x,k in enumerate(counts):ax.text(x,max(k,intervals[x,1])+3,str(k),ha='center',fontweight='bold')
    ax.set_xticks(range(5),classes);ax.set_ylim(0,112);ax.set_yticks([0,20,40,60,80,100]);ax.set_title(title,pad=15);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
axes[0].set_ylabel('100 bağımsız deney içindeki sayı')
fig.suptitle('20. yıl sonunda rejim dağılımı · her modelde 100 deney',fontsize=14,fontweight='bold')
fig.supxlabel('Çubuklar: son 12 ay sınıfları. Çizgiler: Wilson %95 Monte Carlo aralığı.\nSonuçlar model varsayımlarına koşullu; gerçek Fransa olasılıkları değildir.',fontsize=9)
fig.savefig(folder/'regime-distribution.png',dpi=180);fig.savefig(folder/'regime-distribution.svg');plt.close(fig)

analysis=json.loads(Path('v2_results/analysis.json').read_text(encoding='utf-8'))
scenarios=[r for r in analysis['summaries'] if r['name'].startswith('scenario_') or r['name']=='stress']
fig,ax=plt.subplots(figsize=(10,4.6),layout='constrained');left=np.zeros(len(scenarios))
for k,col in zip(keys,palette):
    values=np.array([r['distribution'][k] for r in scenarios]);ax.barh(range(len(scenarios)),values,left=left,color=col,label=k)
    for y,(v,l) in enumerate(zip(values,left)):
        if v>0:ax.text(l+v/2,y,str(v),ha='center',va='center',color='white' if col in ['#ca4c5a','#8c64b5'] else 'black',fontweight='bold')
    left+=values
names=[r['config']['parameters']['scenario']+(' · stres' if r['name']=='stress' else '') for r in scenarios]
ax.set_yticks(range(len(scenarios)),names);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('Her koşulda 100 bağımsız deney');ax.set_title('V2 · başlangıç koşulları ve ayrı stres deneyi');ax.legend(loc='lower center',bbox_to_anchor=(.5,-.38),ncol=5,frameon=False);fig.savefig(folder/'initial-conditions.png',dpi=180);plt.close(fig)

old=json.loads(Path('audit_results/audit.json').read_text(encoding='utf-8'));new=json.loads(Path('v2_results/scenario_0/summary.json').read_text(encoding='utf-8'))
fig,ax=plt.subplots(figsize=(10,5.2),layout='constrained');x=np.arange(6);w=.25
ax.bar(x-w,[100*r['exact_boundary_share_all'] for r in old['boundaries']],width=w,label='V1 · tam 0/1',color='#ca4c5a');ax.bar(x,[100*new['exact_boundary_share'][k] for k in METRICS],width=w,label='V2 · tam 0/1',color='#1b9e77');ax.bar(x+w,[100*new['near_boundary_share'][k] for k in METRICS],width=w,label='V2 · ≤.01 / ≥.99',color='#d6a044');ax.set_xticks(x,[LABELS[k].replace(' ','\n',1) for k in METRICS]);ax.set_ylabel('Bütün aylık kayıtlar içinde pay (%)');ax.set_ylim(0,100);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True);ax.set_title('Tam sınır sorunu ve kalan sınıra yakın kutuplaşma');ax.legend(frameon=False,loc='upper right');fig.savefig(folder/'boundary-diagnostics.png',dpi=180);plt.close(fig)
print('Research figures written.')
