"""Predeclared V2 study. No outcome-dependent parameter selection."""
from dataclasses import asdict,replace
from pathlib import Path
import concurrent.futures,json,time,hashlib,platform
import numpy as np
import pandas as pd
import mesa
import model_v2 as v2
from audit_v1 import jacobian
from scipy.optimize import least_squares

VARIANTS=[('resilience',.5),('resilience',1.5),('shock_scale',0.),('shock_scale',1.5),('leader_bias',-.25),('leader_bias',.25),('self_feedback',.5),('self_feedback',1.5),('conflict_resolution',.5),('conflict_resolution',1.5)]

def task(spec):
    name,config=spec;start=time.perf_counter();p=v2.Parameters(**config)
    h,e,o=v2.experiment(p,100,2026)
    folder=Path('v2_results')/name;folder.mkdir(parents=True,exist_ok=True)
    h.to_csv(folder/'monthly.csv',index=False);e.to_csv(folder/'events.csv',index=False);o.to_csv(folder/'outcomes.csv',index=False)
    meta={'parameters':asdict(p),'runs':100,'base_seed':2026,'months':240,'model_version':'2.0','python':platform.python_version(),'mesa':mesa.__version__,'warning':'Varsayımsal araştırma adayı; Fransa tahmini değildir.'}
    if name.startswith('scenario_'):
        (folder/'experiment.json').write_text(json.dumps({'metadata':meta,'monthly':h.to_dict('records'),'events':e.to_dict('records'),'outcomes':o.to_dict('records')},ensure_ascii=False,allow_nan=False),encoding='utf-8')
    summary={'name':name,'config':meta,'distribution':{k:int((o.regime==k).sum()) for k in ['Demokrasi','Otoriter','İç savaş','Kırılgan yönetim','Hibrit']},'near_boundary_share':{k:float(((h[k]<=.01)|(h[k]>=.99)).mean()) for k in v2.METRICS},'exact_boundary_share':{k:float(h[k].isin([0,1]).mean()) for k in v2.METRICS},'late_mean_sd':float(o.late_mean_sd.mean()),'mean_violence':float(o.mean_violence.mean()),'sustained_high_violence_rate':float(o.sustained_high_violence.mean()),'seconds':time.perf_counter()-start}
    (folder/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return summary

def stability():
    micro=np.array([.5,.5,.4,.55,.5,.5,.6,.5]);rows=[]
    pressure=np.array([.28,.09,.008*.8/.06]);rng=np.random.default_rng(731)
    starts=[np.array(x) for x in v2.SCENARIOS.values()]+[rng.uniform(.05,.95,6) for _ in range(5)]
    for fb in [.5,1.,1.5]:
        for A in [.25,.5,.75]:
            mm=micro.copy();mm[0]=A;p=v2.Parameters(self_feedback=fb)
            fn=lambda x:v2.flow_map(x,mm,pressure,0,p)
            found=[]
            for start in starts:
                x=start.copy()
                for _ in range(2000):
                    y=fn(x)
                    if np.max(np.abs(y-x))<1e-12:x=y;break
                    x=y
                candidates=[x,least_squares(lambda x:fn(x)-x,np.clip(start,1e-8,1-1e-8),bounds=(0,1),gtol=1e-11,ftol=1e-11,xtol=1e-11).x]
                for x in candidates:
                    residual=float(np.max(np.abs(fn(x)-x)))
                    if residual>1e-7 or any(np.linalg.norm(x-y)<1e-4 for y in found):continue
                    found.append(x);eig=np.linalg.eigvals(jacobian(fn,x));rho=float(np.max(np.abs(eig)))
                    rows.append({'self_feedback':fb,'A':A,**dict(zip(v2.METRICS,map(float,x))),'residual':residual,'spectral_radius':rho,'local_label':'çekici (donmuş kapanış)' if rho<1-1e-5 else 'kararsız/sınır durum'})
    return rows

def finalize(summaries):
    p=Path('v2_results');base=pd.read_csv(p/'scenario_0/outcomes.csv');baseline=(base.regime=='Otoriter').astype(int).to_numpy();sensitivity=[];scenario_outcomes=[]
    for i,name in enumerate(v2.SCENARIOS):
        o=pd.read_csv(p/f'scenario_{i}/outcomes.csv');o['scenario']=name;scenario_outcomes.extend(o.to_dict('records'))
    for i,(key,value) in enumerate(VARIANTS):
        o=pd.read_csv(p/f'variant_{i}/outcomes.csv');y=(o.regime=='Otoriter').astype(int).to_numpy();delta=y-baseline
        sensitivity.append({'parameter':key,'value':value,'authoritarian_rate':float(y.mean()),'paired_difference':float(delta.mean()),'paired_mc_se':float(delta.std(ddof=1)/10),'distribution':o.regime.value_counts().to_dict(),'mean_violence':float(o.mean_violence.mean()),'sustained_high_violence_rate':float(o.sustained_high_violence.mean())})
    threshold=[]
    for change in [-.05,0,.05]:
        flags=(base.mean12_concentration>=.70+change)&(base.mean12_liberties<=.35-change)&(base.mean12_independence<=.35-change)&(base.mean12_violence<.60)
        threshold.append({'strictness_shift':change,'authoritarian_count':int(flags.sum())})
    meta=json.loads((p/'scenario_0/experiment.json').read_text(encoding='utf-8'))['metadata']
    roots=stability()
    result={'metadata':meta,'sensitivity':sensitivity,'scenario_outcomes':scenario_outcomes,'summaries':sorted(summaries,key=lambda r:r['name']),'threshold_sensitivity':threshold,'fixed_points_frozen':roots,'source_sha256':hashlib.sha256(Path('model_v2.py').read_bytes()).hexdigest(),'preregistration':json.loads(Path('research/v2/preregistration.json').read_text(encoding='utf-8'))}
    (p/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print('FINAL',json.dumps([(x['name'],x['distribution']) for x in result['summaries']],ensure_ascii=False),flush=True)

if __name__=='__main__':
    base=v2.Parameters();specs=[(f'scenario_{i}',asdict(replace(base,scenario=name))) for i,name in enumerate(v2.SCENARIOS)]
    specs += [(f'variant_{i}',asdict(replace(base,**{key:value}))) for i,(key,value) in enumerate(VARIANTS)]
    specs += [('stress',asdict(replace(base,scenario='Parçalanma',shock_scale=3,conflict_resolution=.5)))]
    Path('research/v2/source_manifest.json').write_text(json.dumps({'sha256_before_runs':hashlib.sha256(Path('model_v2.py').read_bytes()).hexdigest(),'specs':specs},ensure_ascii=False,indent=2),encoding='utf-8')
    with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
        summaries=[]
        for f in concurrent.futures.as_completed([pool.submit(task,spec) for spec in specs]):
            r=f.result();summaries.append(r);print(r['name'],r['distribution'],round(r['seconds'],1),'sec',flush=True)
    finalize(summaries)
