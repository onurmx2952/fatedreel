from pathlib import Path
import shutil
p=Path('web');p.mkdir(exist_ok=True)
for name in ['model.py','model_v2.py','AUDIT_V1.md','MODEL.md','MODEL_V2.md','MODEL_V2_IMPLEMENTATION.md','STUDY_V2.md']:
    shutil.copyfile(name,p/name)
for source,dest in [('results/experiment.json','experiment.json'),('results/analysis.json','analysis.json'),('v2_results/scenario_0/experiment.json','experiment-v2.json'),('v2_results/analysis.json','analysis-v2.json'),('audit_results/audit.json','audit.json'),('v2_results/stability_details.json','stability_details.json'),('research/v2/preregistration.json','preregistration.json'),('research/v2/source_manifest.json','source_manifest.json')]:
    if Path(source).exists():shutil.copyfile(source,p/dest)
for file in Path('figures').glob('*'):
    if file.suffix in ['.png','.svg']:shutil.copyfile(file,p/file.name)
print('Web data prepared; download_runtime.py supplies the same-origin Python runtime.')
